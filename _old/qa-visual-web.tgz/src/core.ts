import { mkdirSync, copyFileSync, existsSync, writeFileSync } from 'node:fs';
import { join, relative, basename } from 'node:path';
import type { Browser } from 'playwright';
import { log, VIEWPORTS, type Config } from './config.js';
import { launch, captureAll, type Capture } from './capture.js';
import { sweep, type SweepResult } from './sweep.js';
import { compare } from './compare.js';
import { renderReport, type RunReport, type PageReport, type ViewportReport } from './report.js';
import { listFigmaFrames, renderFigmaFrames, framesFromFolder, type FigmaFrame } from './design.js';
import { fromSitemap, fromLinks, browserFetcher, dedupeUrls, slugOf, type PageTarget } from './pages.js';
import { mapUrlsToFrames, looksMispaired, type Mapped } from './mapping.js';
import { detectShared } from './shared.js';
import { groupFindings, type Occurrence } from './group.js';
import { createProvider, type VisionProvider } from './provider.js';
import { compareWithDesign, compareSelf } from './ai.js';
import { annotateCrop } from './annotate.js';
import { locate } from './locate.js';

/**
 * The engine, with no opinion about how it is driven.
 *
 * Two entry points — work out the pairing, then run the QA on a pairing someone approved. The CLI
 * and the web server are both thin shells over these; keeping the logic here is what stops the two
 * front ends from slowly growing different behaviour.
 */

/** Run a few pages at a time — a browser context each, but not so many that the machine crawls. */
export async function pool<T, R>(items: T[], size: number, fn: (item: T, i: number) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let next = 0;
  await Promise.all(
    Array.from({ length: Math.min(size, items.length) }, async () => {
      while (true) {
        const i = next++;
        if (i >= items.length) return;
        out[i] = await fn(items[i], i);
      }
    }),
  );
  return out;
}

/* ================================ discover ================================ */

export interface DiscoveredFrame {
  id: string;
  name: string;
  width: number;
  height: number;
  /** file on disk, when rendered */
  file?: string;
  /** basename the server can serve as a thumbnail */
  thumb?: string;
}

export interface Discovery {
  pages: PageTarget[];
  frames: DiscoveredFrame[];
  /** how the page list came about, for the UI to show */
  pagesFrom: string;
}

/** The page list for a site: its sitemap if it has one, else the links on its homepage. */
export async function findPages(browser: Browser, siteUrl: string, maxPages: number): Promise<{ urls: string[]; from: string }> {
  let urls = await fromSitemap(siteUrl, maxPages, browserFetcher(browser));
  let from = 'sitemap.xml';
  if (!urls.length) {
    urls = await fromLinks(browser, siteUrl, maxPages);
    from = 'liên kết trên trang chủ';
  }
  urls = dedupeUrls([siteUrl, ...urls]).slice(0, maxPages);
  return { urls, from };
}

/**
 * Work out which URL goes with which design frame, and render every candidate frame.
 *
 * Every candidate, not only the ones that won a pairing: the whole point of showing this in a
 * browser is that a person judges the pairing by looking at the design, and they cannot judge a
 * frame that was never rendered. The renders are cached by file+node, so this is paid once.
 */
export async function discover(cfg: Config): Promise<Discovery> {
  const browser = await launch(cfg);
  try {
    const site = cfg.site ?? cfg.url;
    const { urls, from } = await findPages(browser, site, cfg.maxPages);
    log(`${urls.length} trang: ${urls.map((u) => new URL(u).pathname).join(', ')}`);

    let frames: FigmaFrame[] = [];
    try {
      if (cfg.figma) frames = await listFigmaFrames(cfg.figma, cfg.figmaToken);
      else if (cfg.designDir) frames = framesFromFolder(cfg.designDir);
    } catch (e: any) {
      log(`design: ${e?.message ?? e}`);
    }

    const mapped = mapUrlsToFrames(urls, frames);
    const rendered = await renderAll(cfg, frames);

    return {
      pages: mapped.map((m) => ({ url: m.url, figmaNodeId: m.figmaNodeId, frameName: m.frameName, how: m.how })),
      frames: frames.map((f) => withThumb(f, rendered)),
      pagesFrom: from,
    };
  } finally {
    await browser.close().catch(() => {});
  }
}

function withThumb(f: FigmaFrame, rendered: Map<string, string>): DiscoveredFrame {
  const file = f.file ?? rendered.get(f.id);
  return { id: f.id, name: f.name, width: f.width, height: f.height, file, thumb: file ? basename(file) : undefined };
}

/** Render frames to PNG (Figma) or take the files as they are (design folder). */
export async function renderAll(cfg: Config, frames: FigmaFrame[]): Promise<Map<string, string>> {
  if (!frames.length) return new Map();
  if (!cfg.figma) {
    const out = new Map<string, string>();
    for (const f of frames) if (f.file) out.set(f.id, f.file);
    return out;
  }
  return renderFigmaFrames(cfg.figma, frames, cfg.figmaToken, designCache(cfg)).catch((e) => {
    log(`Figma render: ${e?.message ?? e}`);
    return new Map<string, string>();
  });
}

export const designCache = (cfg: Config) => join(cfg.stateDir, '_design');

/* ================================== run =================================== */

/** Phase 1 for one URL: capture the three viewports and diff each against that URL's own baseline. */
async function capturePage(
  browser: Browser,
  cfg: Config,
  runDir: string,
  approvedRoot: string,
  target: Mapped,
  designFile: string | undefined,
): Promise<{ page: PageReport; caps: Capture[]; pageDir: string }> {
  const slug = slugOf(target.url);
  const pageDir = join(runDir, slug);
  const caps = await captureAll(browser, { ...cfg, url: target.url }, pageDir);
  // Each URL keeps its OWN approved baseline — one shared folder would have every page
  // overwriting the previous one's reference.
  const approvedDir = join(approvedRoot, slug);

  const viewports: ViewportReport[] = [];
  for (const cap of caps) {
    const baseline = join(approvedDir, `${cap.viewport}.png`);
    const diff = compare(existsSync(baseline) ? baseline : undefined, cap.file, cap.media, join(pageDir, `${cap.viewport}.diff.png`));
    const failedSet = new Set(cap.failedRequests.map((f) => f.split(' ').pop()!.split('?')[0]));
    viewports.push({
      name: cap.viewport,
      width: cap.width,
      shot: relative(runDir, cap.file),
      pageHeight: cap.pageHeight,
      diff: { ...diff, diffRel: diff.diffFile ? relative(runDir, diff.diffFile) : undefined },
      design: designFile ? { file: relative(runDir, designFile), mode: 'x' as any, source: target.frameName ?? '', width: target.frame?.width ?? 0 } : undefined,
      brokenImages: cap.media.filter((m) => m.kind === 'img' && m.broken),
      distortedImages: cap.media.filter((m) => m.kind === 'img' && (m.distortion ?? 0) > 0.15),
      failedBackgrounds: cap.media
        .filter((m) => m.kind === 'background' && m.src && failedSet.has(m.src.split('?')[0]))
        .map((m) => {
          const line = cap.failedRequests.find((f) => f.includes(m.src!.split('?')[0])) ?? '';
          const why = line.startsWith('HTTP') ? line.split(' ').slice(0, 2).join(' ') : line.split(' ')[0] || 'failed';
          return { ...m, why };
        }),
      mediaRegions: cap.media,
      textIndex: cap.textIndex,
    });
  }

  return {
    page: {
      url: target.url,
      slug,
      title: caps[0]?.title ?? '',
      viewports,
      mapping: { frameName: target.frameName, frameWidth: target.frame?.width, how: target.how, score: target.score, isTemplate: target.isTemplate },
      designFile: designFile ? relative(runDir, designFile) : undefined,
      mispaired: false,
      failedRequests: caps[0]?.failedRequests ?? [],
      jsErrors: caps[0]?.jsErrors ?? [],
    } as PageReport,
    caps,
    pageDir,
  };
}

/**
 * Phase 2 for one URL: ask the model about the design, but tell it which y bands are the shared
 * header/footer already reviewed on another page. Without that it re-describes the same footer on
 * every page — wasted tokens, and wasted model attention that should go to the page's own content.
 */
async function analysePage(
  runDir: string,
  pageDir: string,
  page: PageReport,
  target: Mapped,
  designFile: string | undefined,
  provider: VisionProvider,
  skipBands: Array<{ from: number; to: number; where: string }>,
): Promise<{ occurrences: Occurrence[]; aiError?: string; mispaired: boolean }> {
  const occurrences: Occurrence[] = [];
  let aiError: string | undefined;
  let mispaired = false;
  const viewports = page.viewports;

  if (designFile && target.frame) {
    const titles: string[] = [];
    await Promise.all(
      viewports.map(async (v) => {
        const vpH = VIEWPORTS.find((x) => x.name === v.name)?.height ?? 900;
        const mode = Math.abs(target.frame!.width - v.width) / v.width <= 0.12 ? 'fidelity' : 'adaptation';
        try {
          const found = await compareWithDesign(provider, join(runDir, v.shot), designFile, mode, v.width, target.frame!.width, vpH, v.mediaRegions, skipBands);
          for (const f of found) {
            titles.push(f.title);
            const loc = locate(f.anchors, v.textIndex, f.y);
            if (loc) {
              f.locatedHow = loc.how;
              const res = annotateCrop(join(runDir, v.shot), loc.box, occurrences.length + 1, join(pageDir, `${v.name}.f${occurrences.length + 1}.png`));
              if (res) f.crop = relative(runDir, res.file);
            }
            occurrences.push({ url: page.url, viewport: v.name, finding: f });
          }
        } catch (e: any) {
          aiError = String(e?.message ?? e).slice(0, 200);
        }
      }),
    );
    mispaired = looksMispaired(titles);
  }

  const d = viewports.find((v) => v.name === 'desktop');
  const m = viewports.find((v) => v.name === 'mobile');
  if (d && m) {
    try {
      const mH = VIEWPORTS.find((x) => x.name === 'mobile')?.height ?? 844;
      const found = await compareSelf(provider, join(runDir, d.shot), join(runDir, m.shot), mH, m.mediaRegions);
      for (const f of found) {
        const loc = locate(f.anchors, m.textIndex, f.y);
        if (loc) {
          f.locatedHow = loc.how;
          const res = annotateCrop(join(runDir, m.shot), loc.box, occurrences.length + 1, join(pageDir, `self.f${occurrences.length + 1}.png`));
          if (res) f.crop = relative(runDir, res.file);
        }
        occurrences.push({ url: page.url, viewport: 'mobile', finding: f });
      }
    } catch {
      /* self-compare is a bonus; never fail the page for it */
    }
  }
  return { occurrences, aiError, mispaired };
}

export interface RunOutcome {
  runDir: string;
  reportPath: string;
  stamp: string;
  report: RunReport;
}

/**
 * Run the QA on a pairing that has already been settled.
 *
 * The pairing arrives as rows, not as a file, so the caller decides where it came from: the CLI
 * reads pages.json, the web UI hands over what the human just edited on screen.
 */
export async function runQa(cfg: Config, rows: PageTarget[], frames: FigmaFrame[]): Promise<RunOutcome> {
  const t0 = Date.now();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const runDir = join(cfg.stateDir, stamp);
  const approvedRoot = join(cfg.stateDir, '_approved');
  mkdirSync(runDir, { recursive: true });

  const mapped: Mapped[] = rows.map((p) => {
    // A hand-edited row names the frame; the id is what the tool wrote. Name wins, because the
    // name is the part a person can actually pick correctly.
    const byName = p.frameName ? frames.find((f) => f.name === p.frameName) : undefined;
    const byId = p.figmaNodeId ? frames.find((f) => f.id === p.figmaNodeId) : undefined;
    const frame = byName ?? byId;
    return {
      ...p,
      frame,
      frameName: frame?.name ?? p.frameName,
      figmaNodeId: frame?.id ?? p.figmaNodeId,
      score: 1,
      runnerUp: 0,
      isTemplate: false,
      how: p.how ?? (frame ? `ghép tay: "${frame.name}"` : 'không ghép design → chỉ kiểm responsive'),
    } as Mapped;
  });
  const urls = mapped.map((m) => m.url);

  const usedFrames = mapped.map((m) => m.frame).filter(Boolean) as FigmaFrame[];
  const rendered = await renderAll(cfg, usedFrames);

  const provider = createProvider(cfg);
  const browser = await launch(cfg);
  let report: RunReport;

  try {
    // ---- phase 1: capture everything first. The template can only be identified by comparing pages.
    const captured = await pool(mapped, cfg.concurrency, (m) =>
      capturePage(browser, cfg, runDir, approvedRoot, m, m.frame ? rendered.get(m.frame.id) : undefined),
    );

    // ---- what is template chrome, from counting text across pages
    const shared = detectShared(
      captured.map((r) => ({
        url: r.page.url,
        textIndex: r.page.viewports.find((v) => v.name === 'mobile')?.textIndex ?? [],
        pageHeight: r.page.viewports.find((v) => v.name === 'mobile')?.pageHeight ?? 0,
      })),
    );
    if (shared.texts.size) log(`vùng dùng chung: ${shared.texts.size} chuỗi chữ có mặt ở ≥60% trang`);

    // ---- phase 2: the AI pass. The first page reviews the whole thing; later pages are told to
    // skip the shared header/footer, so the same component is not described over and over.
    const allOccurrences: Occurrence[] = [];
    if (provider) {
      let reviewedTemplate = false;
      await pool(captured, cfg.concurrency, async (r, i) => {
        const m = mapped[i];
        const bands = reviewedTemplate ? (shared.bands.get(r.page.url) ?? []) : [];
        if (!reviewedTemplate) reviewedTemplate = true;
        const res = await analysePage(runDir, r.pageDir, r.page, m, m.frame ? rendered.get(m.frame.id) : undefined, provider, bands);
        r.page.aiError = res.aiError;
        r.page.mispaired = res.mispaired;
        allOccurrences.push(...res.occurrences);
      });
    }

    // ---- one finding per defect
    const grouped = groupFindings(allOccurrences, shared);
    const templateCount = grouped.filter((g) => g.scope === 'template').length;
    log(`gộp: ${allOccurrences.length} nhận xét thô → ${grouped.length} lỗi (${templateCount} ở component dùng chung)`);

    // ---- sweep the homepage for the width where layout breaks
    const sweeps: Array<{ url: string } & SweepResult> = [];
    const s = await sweep(browser, urls[0]).catch(() => null);
    if (s) sweeps.push({ url: urls[0], ...s });

    // ---- approve
    const firstEver = !existsSync(join(approvedRoot, slugOf(urls[0]), 'meta.json'));
    const approvedThisRun = cfg.approve || firstEver;
    if (approvedThisRun) {
      for (const r of captured) {
        const dir = join(approvedRoot, r.page.slug);
        mkdirSync(dir, { recursive: true });
        for (const cap of r.caps) copyFileSync(cap.file, join(dir, `${cap.viewport}.png`));
        writeFileSync(join(dir, 'meta.json'), JSON.stringify({ url: r.page.url, at: new Date().toISOString(), run: stamp }, null, 2));
      }
      log(firstEver ? 'lần chạy đầu → đã lưu làm bản duyệt' : 'đã chốt lần chạy này làm bản duyệt mới');
    }

    report = {
      site: cfg.site ?? cfg.url,
      when: new Date().toISOString(),
      durationMs: Date.now() - t0,
      approvedThisRun,
      pages: captured.map((r) => r.page),
      findings: grouped,
      sweeps,
      sharedTextCount: shared.texts.size,
      aiModel: provider ? `${provider.name}/${provider.model}` : undefined,
      rawFindingCount: allOccurrences.length,
    };
  } finally {
    await browser.close().catch(() => {});
  }

  const reportPath = join(runDir, 'report.html');
  writeFileSync(reportPath, renderReport(report));
  const slim = { ...report, pages: report.pages.map((p) => ({ ...p, viewports: p.viewports.map(({ textIndex, ...rest }) => rest) })) };
  writeFileSync(join(runDir, 'report.json'), JSON.stringify(slim, null, 2));

  const changed = report.pages.filter((p) => p.viewports.some((v) => v.diff.changed)).length;
  log(
    `xong trong ${((Date.now() - t0) / 1000).toFixed(0)}s — ${report.pages.length} trang, ${report.findings.length} lỗi (${report.findings.filter((f) => f.scope === 'template').length} dùng chung), ${changed} trang khác bản duyệt`,
  );
  return { runDir, reportPath, stamp, report };
}
